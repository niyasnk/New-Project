package com.example.install.webviewapp;

import junit.framework.TestCase;

/**
 * Created by install on 9/26/2018.
 */
public class MainActivityTest extends TestCase {

}