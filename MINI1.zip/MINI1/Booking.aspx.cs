﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;



public partial class Booking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        int f = 0;
        SqlConnection objcon = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=registration;Integrated Security=true");
        objcon.Open();
        SqlDataAdapter objdataadapter = new SqlDataAdapter("select * from tab_reg", objcon);
        DataSet objdataset = new DataSet();
        objdataadapter.Fill(objdataset, "tab_reg");
        foreach (DataTable table in objdataset.Tables)
        {
            foreach (DataRow row in table.Rows)
            {
                if (txtemail.Text.ToString().Trim().ToUpper().Equals(row["email"].ToString().Trim().ToUpper()))
                {
                    lblmessage.Text = "Email Address already exists";
                    f = 1;
                    break;
                }
            
              if (txtmob.Text.ToString().Trim().ToUpper().Equals(row["mobile"].ToString().Trim().ToUpper()))
                {
                    lblmobile.Text = "Mobile No. already exists";
                    f = 1;
                    break;
                }
           
                if (txtpass.Text.ToString().Trim().ToUpper().Equals(row["password"].ToString().Trim().ToUpper()))
                {
                    lblpassword.Text = "Password already exists";
                    f = 1;
                    break;
                }

            }
            if (f == 1)
                break;

        }
        if (f == 0)
        {
            SqlCommand objcomm = new SqlCommand();
            objcomm.Connection = objcon;
            objcomm.CommandText = "insert into tab_reg(name,age,gender,address,place,state,country,mobile,email,password,cpassword) values('" + txtname.Text.ToString() + "','" + txtage.Text.ToString() + "','" + rbgender.Text.ToString() + "','" + txtadd.Text.ToString() + "','" + txtplace.Text.ToString() + "','" + txtstate.Text.ToString() + "','" + txtcountry.Text.ToString() + "','" + txtmob.Text.ToString() + "','" + txtemail.Text.ToString() + "','" + txtpass.Text.ToString() + "','" + txtcpass.Text.ToString() + "')";
            objcomm.ExecuteNonQuery();
            Response.Write("<Script>alert('Successfully Inserted')</script>");
        }
     
    }
    

    }


        
  


      



