﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        int f = 0;
        SqlConnection objcon = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=registration;Integrated Security=true");
        objcon.Open();
        SqlDataAdapter objdataadapter = new SqlDataAdapter("select * from tab_reg", objcon);
        DataSet objdataset = new DataSet();
        objdataadapter.Fill(objdataset, "tab_reg");
        foreach (DataTable table in objdataset.Tables)
        {
            foreach (DataRow row in table.Rows)
            {
                if (txtemail.Text.ToString().Trim().ToUpper().Equals(row["email"].ToString().Trim().ToUpper()))
                {
                    Response.Redirect("User.aspx");
                    f = 1;
                    break;
                }
            }
        }
        if (f == 0)
        {

            SqlConnection objconnection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=logn;Integrated Security=true");
            objconnection.Open();
            SqlDataAdapter dataadapter = new SqlDataAdapter("select * from tab_logn", objconnection);
            DataSet odataset = new DataSet();
            dataadapter.Fill(odataset, "tab_logn");
            foreach (DataTable table in odataset.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    if (txtemail.Text.ToString().Trim().ToUpper().Equals(row["email"].ToString().Trim().ToUpper()))
                    {
                        Response.Redirect("Admin.aspx");

                    }
                }

            }
        }
        Response.Write("<script>alert('Invalid User')</script>");
    }
}
        

